package demo.account;

public enum CreditCardType {
    VISA,
    MASTERCARD,
    AMERICAN_EXPRESS
}
